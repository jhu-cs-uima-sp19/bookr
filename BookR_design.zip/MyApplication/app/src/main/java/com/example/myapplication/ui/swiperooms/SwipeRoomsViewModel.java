package com.example.myapplication.ui.swiperooms;

import androidx.lifecycle.ViewModel;

public class SwipeRoomsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
