package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.HashMap;

public class ConfirmPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_page);


        Intent old_intent = getIntent();
        Bundle extras = old_intent.getExtras();
        String room_num = null;
        if(extras != null) {
            room_num = extras.getString("room_num");
        }

        setTitle(room_num);

        ArrayList<String> selections = old_intent.getStringArrayListExtra("selections");
        for (int j = 0; j < selections.size(); j++) {
            Log.d("test", selections.get(j) + "");
        }
    }



    public void confirmRooms(View ib) {
        Intent intent = new Intent(this, LaunchActivity.class);
        startActivity(intent);
    }
    public void cancelRoom(View ib) {
        finish();
    }

    private void setTitle(String input) {
        this.getSupportActionBar().setTitle(input);
    }
}
