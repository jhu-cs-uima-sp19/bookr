package com.example.apitesting;


import android.annotation.TargetApi;
import android.app.Activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.RestrictTo;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;


public class MainActivity extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDatafromAPI();

        SharedPreferences m = getSharedPreferences("com.example.apitesting",  MODE_PRIVATE);
        String string_data = m.getString("Response","DNE");

        //Recover JSONArray
        JSONArray data = null;
        if (string_data != "DNE") {
            try {
                data = new JSONArray(string_data);
            } catch (JSONException e) {
                Log.e("error", "could not recover JSONArray from SharedPref");
            }
        }

        HashMap<String, ArrayList<ArrayList<String>>> info = makeMap(data);
        HashMap<String, boolean[]> availabilities = new HashMap<>();


        for (HashMap.Entry<String, ArrayList<ArrayList<String>>> entry : info.entrySet()) {
            boolean[] time_slots = roomAvailability(info, entry.getKey());
            availabilities.put(entry.getKey(), time_slots);
        }

        for (HashMap.Entry<String, boolean[]> thing : availabilities.entrySet()) {
            System.out.println(thing);
        }
    }

    private void getDatafromAPI() {
        TextView textView = findViewById(R.id.thing);
        String url = "https://jhu.libcal.com/1.1/oauth/token";
        String url2 = "https://jhu.libcal.com/1.1/space/bookings";

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest accessTokenRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                String access_token = response.substring(17, 57);
                JsonArrayRequest dataRequest = new JsonArrayRequest(Request.Method.GET, url2, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        textView.setText(response.toString());
                        sharedResponse(response.toString());
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        textView.setText("Data Access Failed");
                        Log.e("failed", error.toString());
                    }
                }) {

                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("Authorization", "Bearer " + access_token);
                        return params;
                    }
                };
                queue.add(dataRequest);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText("That didn't work!");
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("grant_type", "client_credentials");
                params.put("client_id", "471");
                params.put("client_secret", "c642b905a3c947952dd49285625ee369");
                return params;
            }
        };

        queue.add(accessTokenRequest);
    }

    private void sharedResponse(String response) {
        SharedPreferences m = getSharedPreferences("com.example.apitesting",  MODE_PRIVATE);
        SharedPreferences.Editor editor = m.edit();
        editor.putString("Response", response);
        editor.commit();
    }

    private HashMap<String, ArrayList<ArrayList<String>>> makeMap(JSONArray data) {
        HashMap<String, ArrayList<ArrayList<String>>> info = new HashMap<>();
        for (int i = 0; i < data.length(); i++) {
            try {
                String eid = data.getJSONObject(i).getString("eid");

                String startTime = data.getJSONObject(i).getString("fromDate");
                String endTime = data.getJSONObject(i).getString("toDate");
                ArrayList<String> times = new ArrayList<>();
                times.add(startTime);
                times.add(endTime);

                if (!info.containsKey(eid)) {
                    ArrayList<ArrayList<String>> current = new ArrayList<>();
                    current.add(times);
                    info.put(eid, current);
                } else {
                    ArrayList<ArrayList<String>> current = info.get(eid);
                    current.add(times);
                    info.put(eid,current);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return info;
    }

    private boolean[] roomAvailability(HashMap<String, ArrayList<ArrayList<String>>> info, String room_number) {

        // For one specific room
        boolean[] time_slots = new boolean[96];
        DateFormat dateFormat = new SimpleDateFormat("HH:mm");
        DateFormat dateFormat2 = new SimpleDateFormat("dd");
        Date date = new Date();
        int index = 2 * Integer.parseInt(dateFormat.format(date).substring(0,2));
        if (Integer.parseInt(dateFormat.format(date).substring(3)) >= 30) {
            index++;
        }

        for (int i = index; i < time_slots.length; i++) {
            time_slots[i] = true;
        }

        ArrayList<ArrayList<String>> room_bookings = info.get(room_number);
        String currentDate = dateFormat2.format(date);
        for (int j = 0; j < room_bookings.size(); j++) {
            String start_date = room_bookings.get(j).get(0).substring(8,10);
            String end_date = room_bookings.get(j).get(1).substring(8,10);

            int startIndex = 2 * Integer.parseInt(room_bookings.get(j).get(0).substring(11,13));
            if (Integer.parseInt(room_bookings.get(j).get(0).substring(14,16)) >= 30) {
                startIndex++;
            }
            if (start_date != currentDate) {
                startIndex += 48;
            }

            int endIndex = 2 * Integer.parseInt(room_bookings.get(j).get(1).substring(11,13));
            if (Integer.parseInt(room_bookings.get(j).get(1).substring(14,16)) >= 30) {
                endIndex++;
            }
            if (end_date != currentDate) {
                endIndex += 48;
            }

            if (endIndex - startIndex > 4) {
                System.err.println("Duration is too long!!" + room_number);
            } else if (endIndex - startIndex < 0) {
                System.err.println("Duration is negative!!" + room_number);
            }
            for (int l = startIndex; l <= endIndex; l++) {
                time_slots[l] = false;
            }
        }
        return time_slots;
    }
}
